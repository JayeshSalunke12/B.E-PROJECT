# Machine-learning-with-k-nearest-neighbors
Today I made a machine learning project based on k-nearest neighbors.
In this project I have tried to solve problem of Indian Farmers. 
In this project we have a data base which is essential for farming and the farmers to know which crop will be best for them to grow in the field.
We have a data base of around 2200 lines, on the bases of which we can predict which crop will be the best for the farmers to grow in the field.
We can predict for almost 22 different types of crop according to the data.
If we can Implement this project on the ground level then it can help our farmers to grow the best crop according to the condition's.
If their is a new guy in the field of farming, then it will be easy for him/her to select the best crop for farming.  
