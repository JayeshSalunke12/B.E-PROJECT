# The Emporium
Semester 1: Python for Computational Problem Solving Project

Welcome to my E-commerce application 'The Emporium' where you can purchase various items from five categories that are as follows:
* Grocery
* Electronics
* Sports and Gym Equipment
* Furniture
* Appliances

After adding the required items, you will have to choose a coupon that is going to get applied in order to avail a discount. We are also going to suggest you the coupon that gives the maximum discount. The coupons are as follows:
* 15% off. upto Rs.500
* 10% off. upto Rs.750
* 5% off. upto Rs.1000

After applying a coupon, an invoice will get generated that displays the items that have been purchased and the total amount to be paid. This invoice can then be saved in the Invoices folder by just clicking on the Save Invoice button.
